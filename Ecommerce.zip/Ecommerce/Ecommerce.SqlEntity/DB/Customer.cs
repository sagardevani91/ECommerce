﻿using System;
using System.Collections.Generic;

namespace Ecommerce.SqlEntity.DB;

public class Customer
{
    public int Id { get; set; }

    public string? ShippingAddress { get; set; }

    public string? BillingAddress { get; set; }

    public int? UserId { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

    public virtual User? User { get; set; }
}
