﻿using Ecommerce.SqlEntity.DB;
using Ecommerce.SqlEntity.Repository.IRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecommerce.SqlEntity.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly EcommerceContext _dbContext; // Replace YourDbContext with your actual DbContext class

        public CategoryRepository(EcommerceContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Category> GetCategoryByIdAsync(int? categoryId)
        {
            return await _dbContext.Categories.FindAsync(categoryId);
        }

        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            return await _dbContext.Categories.ToListAsync();
        }

        public async Task AddCategoryAsync(Category category)
        {
            await _dbContext.Categories.AddAsync(category);
            await _dbContext.SaveChangesAsync();
        }

        public async Task UpdateCategoryAsync(Category category)
        {
            _dbContext.Entry(category).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteCategoryAsync(int categoryId)
        {
            var category = await _dbContext.Categories.FindAsync(categoryId);
            if (category != null)
            {
                _dbContext.Categories.Remove(category);
                await _dbContext.SaveChangesAsync();
            }
        }
    }
}
