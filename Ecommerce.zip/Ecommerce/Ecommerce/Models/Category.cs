﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Ecommerce.Models;

public class Category
{
    public int Id { get; set; }
    [Required]
    [Display(Name = "Category Name")]
    [StringLength(50, MinimumLength = 2)]
    public string? CategoryName { get; set; }

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
