﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Ecommerce.Models;

public class Customer
{
    public int Id { get; set; }

    [Required]
    [Display(Name = "Shipping Address")]
    public string? ShippingAddress { get; set; }

    [Required]
    [Display(Name = "Billing Address")]
    public string? BillingAddress { get; set; }

    [Required]
    public int? UserId { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

    public virtual User? User { get; set; }
}
